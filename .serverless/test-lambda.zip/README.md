# serverless-beta-nodejs-dynamodb-learn
This is serverless-beta starter application

Using this application you can create simple web API using Micro services architecture.   
