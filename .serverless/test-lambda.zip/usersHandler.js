var user = require('./lib/users');

module.exports.users = function(event, context) {
  console.log(JSON.stringify(event));
  if(event.path === '/users/getUsers' && event.method === 'GET') {
    user.getUsers(event,context);

  } else if(event.path === '/users/createUser' && event.method === 'POST') {
  	user.createUser(event,context);

  } else if(event.path === '/users/updateUser' && event.method === 'POST') {
  	user.updateUser(event,context);

  } else if(event.path === '/users/getUser' && event.method === 'GET'){
  	user.getUser(event,context);
  }
  else{
    context.succeed("path not found!");
  }

};
